#return fonksiyonlar genellikle def lerde return kullanırız 
def mami(a,b,):
    mami = a+b
    return(mami)


a =int(input('1. sayıyaz:'))
b =int(input('2. sayıyaz:'))
print(mami(a,b))
