#Type ve Bool komutları
#type tipini bilmediğimiz bir verinin tipini öğrenmemize yarar int, string ...
#bool değişkenin içinde veri dolu mu boş mu onu anlamamıza sağlıyor
a = 1234
b = 12,5
c = 'merhaba'
d = (  ) #boşluk da bir karakterdir
e = ''
f = 0 #yok demek
g = '0'#karakter oldu

print(type (a))
print(type (b))
print(type (c))

print(bool (a))
print(bool (b))
print(bool (c))
print(bool (d))
print(bool (e))
print(bool (f))
print(bool (g))