# döngüler for
sayilar = '123456789adsvs0'
for sayi in sayilar:
    print(sayi)

print('-----------------')

rakam = '123456789kbdflbdbmdgkbklklgmbl' # buradaki verilerin kaç tane olduğunu sayıyor
a = 1
for sayı in rakam: # elemanları sayıyor
    a +=1  # a daki verileri al ve a ya 1 ekleye ekleye git 
    print(a)

