from logging import exception


a = int(input(' bir ile on arasında değer giriniz:'))

if a > 10:
    raise Exception ('ondan büyük değer girdiniz.') #hatayı oluşturuyoruz yazıyoruz 
else:
    print('başarılı')