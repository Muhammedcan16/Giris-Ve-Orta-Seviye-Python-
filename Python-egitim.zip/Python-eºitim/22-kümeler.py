#kümeler set , {} ,  dict(sözlük yazarken)

a = set('mami')#1 ergüman kullanılır
#a = set(12) #hata verir
d = set(['mami', 'tarık'])
b = {'python', 'yazılım', 'python',12,23.5}
c = {'uzun':'kısa'}

print(type(a))
print(type(b))
print(type(c))

print(b)
print(d)


