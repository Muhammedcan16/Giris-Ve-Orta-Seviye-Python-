#ileri seviye string veri tiplerini göreceğiz
str ='Muhammedcan_özcan'
print(str[4])

print('-------------')

print(str[2:6])#2.ile 6. karakter arası olan kıusmı alacaksın 

print('-------------')

print(str[::-1])#tersten yazar
