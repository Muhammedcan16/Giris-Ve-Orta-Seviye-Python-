#değil ise  !=
sifre = input('şifreyi giriniz:')
a = ('1234')

if sifre == a:
   print ('doğru')
elif sifre != a:
    print ('yalnış')
else:
    print('.')
           
