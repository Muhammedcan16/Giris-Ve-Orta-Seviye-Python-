#kaçış dizileri
print('Python\nYazılım')
print()
print('\tPythonYazılım')
print()
print('\tPythonYazılım\a') #\a sistem bildirim sesini çıkartıyor
print()
print('\1,\2,\3') #emoji vs çıkartıyor